import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class GetCharacters {

    private FileReader file;
    private ArrayList<Character> charactersFromFile;


    GetCharacters(String filename) throws IOException {
        file = new FileReader(filename);
        charactersFromFile = new ArrayList<>();

    }

    ArrayList<Character> CharactersFromFile() throws IOException{
       //this function will return an array of characters which is contained in the file
        //this function will exclude characters such as spaces, tabs and next line

        int tempInt = 0;

        while(tempInt != -1){

            tempInt = file.read();

            if(tempInt != 32 && tempInt != 13 && tempInt != 10) charactersFromFile.add((char)tempInt);
        }

        return charactersFromFile;
    }

    Integer TotalCharacterFile () throws IOException{
        //this function will return the sum of the ascii values in the text file
        //this function will exclude characters such as spaces, tabs and next line

        int tempInt = 0;
        int sum = 0;

        while(tempInt != -1){

            tempInt = file.read();

            if(tempInt != 32 && tempInt != 13 && tempInt != 10) sum += tempInt;
        }

        return sum;
    }

}
