package ScratchWork;

public class TestClass {


    public static void main(String[] args)  {
        // TODO code application logic here
        Character x ='x';
        String sample = "adoru";

        System.out.println("The HashCode of x: " + x.hashCode());
        Character x2 = sample.charAt(4);
        System.out.println(sample.hashCode());
    }
}
