package ScratchWork;

public class SimilarityAlgorithm {

    

}
